var searchData=
[
  ['createdevice_87',['CreateDevice',['../classonet_1_1lidar_1_1DeviceManager.html#aea51d3ed5bbba5f001fe9512f3760f09',1,'onet::lidar::DeviceManager::CreateDevice(const std::string &amp;ip_addr, uint32_t port_num)'],['../classonet_1_1lidar_1_1DeviceManager.html#a0eb1f8ec52dbb506dfdce4441e1004a6',1,'onet::lidar::DeviceManager::CreateDevice(const std::vector&lt; std::string &gt; &amp;file_list, int padding=0)']]]
];
