/**************************************************************************
 * @file:  LidarDevice.h
 * @brief:
 *
 * Copyright (c) 2020-present O-Net Communications (ShenZhen) Limited.
 * All rights reserved.
 *
 *************************************************************************/

#pragma once

#include <functional>

#include "Device.h"
#include "DolphinDevice.h"
#include "PointCloud.h"

namespace onet { namespace lidar {

/**
 * @brief The class is used to communicate with lidar. You can get point cloud
 * data and parameters of the device, and can also change the motion of the device.
 */
class DLLEXPORT LidarDevice : public Device
{
public:
    /**
     * @brief The unique constructor.
     * @param ip_addr the ip address of device
     * @param port_num the port number of device
     */
    LidarDevice(const std::string& ip_addr, uint32_t port_num);
    ~LidarDevice();

    /**
     * @brief Get the port number of the device.
     * @return the port number
     */
    uint32_t GetPortNum() const;

    /**
     * @brief Get the ip address of the device.
     * @return the ip address
     */
    const std::string& GetIPAddress() const;

    /**
     * @brief Get the parameters of the device.
     *   If the Init function has not been called, the return value is incorrect.
     * @return the device parameter
     */
    const LidarParameter& GetLidarParameter() const;

     /**
     * @brief Initialize the device according to the configuration files.
     * @return 0 on success, errorcode otherwise
     */
    int InitDevice();

    /**
     * @brief Initialize the device according to the configuration files.
     * @return true on success, false otherwise
     */
    bool Init() override;

    /**
     * @brief Start receiving the point cloud data.
     * @return true on success, false otherwise
     */
    bool Start() override;

    /**
     * @brief Stop the deviece and the point cloud data will no longer be received.
     * @return true on success, false otherwise
     */
    bool Stop() override;

    /**
     * @brief Get if the device has been started
     * @return true indicates the device is started, otherwise false
     */
    bool IsStarted() const override;

    /**
     * @brief Start saving raw data into dp file.
     * @return true on success, false otherwise
     */
    bool StartSaveRawData();

    /**
     * @brief Stop saving raw data into dp file.
     * @return true on success, false otherwise
     */
    bool StopSaveRawData();

    /**
     * @brief Save lidar parameters
     * @return true on success, false otherwise
     */
    bool SaveParameters();

    /**
     * @brief Stop all jobs and make device uninitialized
     */
    void Reset();

    /**
     * @brief Set the laser parameter of the device.
     *   An exception about device or network might be thrown.
     * @param param the struct of LaserParameter
     */
    void SetLaser(const LaserParameter& param);

    /**
     * @brief Set the scan parameter of the device.
     *   An exception about device or network might be thrown.
     * @param mode the enumeration of ScanMode
     */
    void SetScanMode(ScanMode mode);

    /**
     * @brief Set the format of raw data which will be parsed into point cloud data soon.
     *   An exception about device or network might be thrown.
     * @param type the enumeration of RawDataType
     */
    void SetRawDataType(RawDataType type);

    /**
     * @brief Set the echo parameter of the device.
     *   An exception about device or network might be thrown.
     * @param echo_number the number should be in range 1~4 inclusive
     */
    void SetEchoNumber(int32_t echo_number);

    /**
     * @brief Set the raw data saving config
     */
    void SetRawDataSavingConfig(const RawDataSavingConfig& config);

    /**
     * @brief Set the temperature parameter of the device.
     */
    void SetTemperature(uint32_t temperature);

    /**
     * @brief Set the dac parameter of the device.
     */
    void SetDAC(uint32_t dac);

    void SetGatherSize(uint32_t gather_point_size);
    void SetAmplitudeExclude(uint32_t time_stamp, uint32_t amplitude_exclude);
    void SetGhostExclude(uint32_t high_plusewidth, uint32_t time_difference);
    void SetPulsewidth(uint32_t plusewidth_diff, uint32_t time_fly);
    void SetTimeWin(uint32_t min_time, uint32_t max_time);
    void SetDcAndThreshold(uint32_t dc_q, uint32_t dc_i, uint32_t threshold);

    /**
     * @brief Register point cloud handling callbacks
     */
    template <typename POINT_T>
    void RegisterPointCloudCallback(std::function<void(uint32_t, PointCloud<POINT_T>&)>& f);

    void SetRegisterParameter(DlphRegisterAddress addr, RegisterData data);
    uint32_t GetRegisterParameter(DlphRegisterAddress addr);
#ifdef ENABLE_GALVANOMETER_CALIB
    int SetGalvanometerParameter(int frame, const std::vector<uint16_t>& parm);
#else
    /**
     * @brief Set the view parameter of the device.
     *   An exception about device or network might be thrown.
     * @param param the struct of ViewParameter
     */
    int SetViewSpeed(const ViewParameter& param);
#endif
    /**
     * @brief Sync function to get all LiDAR raw data from the queue.
     * @note  This function can only be called when no point cloud callback is subscribed.
     *        Otherwise, the behavior is undetermined.
     */
    std::vector<std::shared_ptr<RawDataBase>> GetRawData();
#ifdef ENABLE_INTERNAL_CALIB
    /**
     * @brief Enable the process of calculating the points in the specified bounding box
     * @note  If passing in a callback, the callback will be called per point cloud frame.
     */
    void EnableBoxedPointsDetection(
        const BoundingBox& box, std::function<void(uint32_t, const DetectedPointsBox&)> callback);

    /**
     * @brief Disable the process of calculating the points in the specified bounding box
     */
    void DisableBoxedPointsDetection();
#endif
private:
    struct Impl;
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4251)
#endif  // _MSC_VER
    std::shared_ptr<Impl> m_impl;
#ifdef _MSC_VER
#pragma warning(pop)
#endif  // _MSC_VER
};

}}  // namespace onet::lidar
