/**************************************************************************
 * @file: PointCloud.h
 * @brief:
 *
 * Copyright (c) 2021 O-Net Technologies (Group) Limited.
 * All rights reserved.
 *************************************************************************/

#pragma once

#include <common/Global.h>

#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4996)  // eigen deprecated c++17 Meta.h
#endif // _MSC_VER

#if defined(linux) || defined(__linux) || defined(__linux__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wold-style-cast" // eigen
#pragma GCC diagnostic ignored "-Wduplicated-branches" // eigen
#pragma GCC diagnostic ignored "-Wconversion" // eigen
#pragma GCC diagnostic ignored "-Wsign-conversion" // eigen
#pragma GCC diagnostic ignored "-Wuseless-cast" // eigen
#endif // linux
#include <Eigen/Core>
#if defined(linux) || defined(__linux) || defined(__linux__)
#pragma GCC diagnostic pop
#endif // linux

#ifdef _MSC_VER
#pragma warning(pop)
#endif  // _MSC_VER
#include <vector>

namespace onet { namespace lidar {

struct PointXYZI : public Eigen::Vector4f
{
    PointXYZI() : Eigen::Vector4f(0.f, 0.f, 0.f, 0.f) {}

    PointXYZI(float x, float y, float z, float i) : Eigen::Vector4f(x, y, z, i) {}
};

struct PointXYZRGB : public PointXYZI
{
    Eigen::Vector3f color{0.f, 0.f, 0.f};  // r, g, b

    PointXYZRGB() : PointXYZI() {}

    PointXYZRGB(float x, float y, float z, float r, float g, float b)
        : PointXYZI(x, y, z, 1), color(r, g, b)
    {}
};

struct PointRawData : public PointXYZI
{
    int32_t section_num{0};  // left = 0, right = 1
    int32_t pulse_width{0};
    int32_t echo_number{0};
    Eigen::Vector4i raw_data{0, 0, 0, 0};  // mirror, azimuth, elevation, distance

    PointRawData() = default;

    PointRawData(float x, float y, float z, float i, int sec_num, int pulse_wid, int mirror,
                 int azm, int elv, int dist)
        : PointXYZI(x, y, z, i),
          section_num(sec_num),
          pulse_width(pulse_wid),
          raw_data(mirror, azm, elv, dist)
    {}
};

/**
 * @brief Point cloud bounding box represented by min and max vertices
 */
struct BoundingBox
{
    Eigen::Vector3d min_vertex;
    Eigen::Vector3d max_vertex;
};

/**
 * @brief DetectedPointsBox contains the raw data of 4 borders of the specified bounding box
 *     and the theretical points and actual points in the bounding box
 */
struct DetectedPointsBox
{
    float angle_box_up{0};
    float angle_box_down{0};
    float angle_box_left{0};
    float angle_box_right{0};
    uint32_t num_points_in_box_theoretical{0};
    uint32_t num_points_in_box_practical{0};
};

template <typename POINT_T>
struct PointCloud : public std::vector<POINT_T>
{
    PointCloud() = default;

    PointCloud(uint32_t size) : std::vector<POINT_T>(size) {}
};

}}  // namespace onet::lidar
