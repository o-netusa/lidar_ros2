/**************************************************************************
 * @file:  PointCloudIO.h
 * @brief:
 *
 * Copyright (c) 2020-present O-Net Communications (ShenZhen) Limited.
 * All rights reserved.
 *
 *************************************************************************/

#pragma once

#include <DeviceParams.h>
#include <PointCloud.h>
#include <common/Global.h>

#include <memory>
#include <string>
#include <vector>

#ifdef ENABLE_INTERNAL_CALIB
#include <PlaybackDevice.h>

#include <thread>
#endif

namespace onet { namespace lidar {

/**
 * @brief Each point cloud data corresponds to a frame.
 *   An exception about IOIssue may be thrown.
 */
template <typename POINT_T>
void DLLEXPORT ReadPointCloudsFromSource(const std::string &filename,
                                         DlphDeviceParameter &dev_param, DlphFileHeader &dev_info,
                                         std::vector<PointCloud<POINT_T>> &pointclouds,
                                         std::function<bool(PointCloud<POINT_T> &)> = nullptr);

/**
 * @brief Read point cloud data from .bin
 * @note padding - additional data fields for each point
 */
void DLLEXPORT ReadPointCloudFromBin(const std::string &filename, PointCloud<PointXYZI> &pointcloud,
                                     uint32_t padding = 0);
/**
 * @brief Write point cloud data to .bin
 *   Make sure the filename is valid and the path is existing
 * @note padding - additional data fields for each point
 */
void DLLEXPORT WritePointCloudToBin(const std::string &filename,
                                    const PointCloud<PointXYZI> &pointcloud, uint32_t padding = 0);

/**
 * @brief Read point cloud data from .pcd
 * @param padding - additional data fields for each point
 */
void DLLEXPORT ReadPointCloudFromPCD(const std::string &filename, PointCloud<PointXYZI> &pointcloud,
                                     uint32_t padding = 0);
/**
 * @brief Write point cloud data to .pcd
 *   Make sure the filename is valid and the path is existing
 * @param padding - additional data fields for each point
 */
void DLLEXPORT WritePointCloudToPCD(const std::string &filename,
                                    const PointCloud<PointXYZI> &pointcloud, uint32_t padding = 0);

/**
 * @brief Read header from .dp file
 */
void DLLEXPORT ReadHeaderFromFile(const std::string &filename, DlphDeviceParameter &dev_param,
                                  DlphFileHeader &dev_info, std::ifstream &ifs);

/**
 * @brief Check if the packet header belongs to FPGA data
 */
bool DLLEXPORT IsFPGAPacketHeader(std::ifstream &ifs);

/**
 * @brief Estimate point cloud size using device parameters
 */
uint32_t DLLEXPORT EstimatePointSize(const DlphFileHeader &dev_info, const uint32_t &code_wheel);

#ifdef ENABLE_INTERNAL_CALIB
/**
 * @brief Calculate points in the specified bounding box
 *
 * @param dev_param
 * @param box
 * @return DetectedPointsBox
 */
DetectedPointsBox DLLEXPORT CalculatePointsInBox(const DlphDeviceParameter &dev_param,
                                                 const BoundingBox &box);

/**
 * @brief Calculate boundary of the specified bounding box
 *
 * @param box
 * @return DetectedPointsBox
 */
DetectedPointsBox DLLEXPORT CalculateBoundaryOfBox(const BoundingBox &box);
#endif
}}  // namespace onet::lidar
