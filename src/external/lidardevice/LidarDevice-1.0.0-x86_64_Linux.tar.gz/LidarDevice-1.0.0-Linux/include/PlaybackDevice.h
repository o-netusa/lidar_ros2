/**************************************************************************
 * @file:  PlaybackDevice.h
 * @brief:
 *
 * Copyright (c) 2020-present O-Net Communications (ShenZhen) Limited.
 * All rights reserved.
 *
 *************************************************************************/

#pragma once

#include <mutex>

#include <sigslot/signal.hpp>
#include <string>
#include <thread>

#include "Device.h"
#include "PointCloud.h"

namespace onet { namespace lidar {

/**
 * @brief The PlaybackDevice class
 *   It is used to read point cloud data from files, including .dp, .bin, .pcd,
 * .xyz, .xyzn, .xyzrgb, .ply, .pts
 */
class DLLEXPORT PlaybackDevice : public Device
{
public:
    /**
     * @brief The constructor
     * @param file_list the point cloud files
     * @param padding - additional data fields for each point
     */
    PlaybackDevice(const std::vector<std::string>& file_list, uint32_t padding = 0);
    ~PlaybackDevice();

    /**
     * @brief Get the files of point cloud
     */
    const std::vector<std::string>& GetFileList() const;

    /**
     * @brief Initialize the device
     */
    bool Init() override;

    /**
     * @brief Start reading files one by one
     * @return true on success, false otherwise
     */
    bool Start() override;

    /**
     * @brief Stop reading
     */
    bool Stop() override;

    /**
     * @brief Control the reading process
     * @param is_paused  pause if the parameter is true, continue otherwise
     */
    void Pause(bool is_paused);

    /**
     * @brief Set parameter which is used to parse the raw data
     */
    void SetParameter(std::shared_ptr<DlphDeviceParameter> param);

    /**
     * @brief Get current parameter
     */
    const DlphDeviceParameter* GetParameter() const;

    /**
     * @brief Register point cloud handling callback
     */
    template <typename POINT_T>
    void RegisterPointCloudCallback(std::function<void(uint32_t, PointCloud<POINT_T>&)>& f);

    /**
     * @brief Playback total complete signal
     */
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4251)
#endif  // _MSC_VER
    sigslot::signal<> TotalCompleteSignal;

    /**
     * @brief Playback signal frame complete signal
     * @note  The signal callback function expects frame id (uint32_t) and filename (std::string&)
     */
    sigslot::signal<uint32_t, const std::string&> FrameCompleteSignal;
#ifdef _MSC_VER
#pragma warning(pop)
#endif  // _MSC_VER

    /**
     * @brief Get and set frame rate
     */
    uint32_t GetFPS() const;
    void SetFPS(uint32_t fps);
#ifdef ENABLE_INTERNAL_CALIB
    /**
     * @brief Enable the process of calculating the points in the specified bounding box
     */
    void EnableBoxedPointsDetection(
        const BoundingBox& box, std::function<void(uint32_t, const DetectedPointsBox&)> callback);

    /**
     * @brief Disable the process of calculating the points in the specified bounding box
     */
    void DisableBoxedPointsDetection();
#endif
private:
    struct Impl;
#ifdef _MSC_VER
#pragma warning(push)
#pragma warning(disable : 4251)
#endif  // _MSC_VER
    std::shared_ptr<Impl> m_impl;
#ifdef _MSC_VER
#pragma warning(pop)
#endif  // _MSC_VER
};

}}  // namespace onet::lidar
