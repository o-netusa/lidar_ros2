/**************************************************************************
 * @file:  Device.h
 * @brief:
 *
 * Copyright (c) 2020-present O-Net Communications (ShenZhen) Limited.
 * All rights reserved.
 *
 *************************************************************************/

#pragma once

#include <common/Global.h>
#include <common/Semaphore.h>
#include <uuid.h>

#include <atomic>

#include "DeviceParams.h"
#include "PointCloud.h"

namespace onet { namespace lidar {

constexpr char DEFAULT_DATA_FOLDER[]{"raw_data"};

/**
 * @brief Specify raw data saving configurations
 * @note Raw data means LiDAR raw data, which can be converted into the stardand point cloud data.
 */
struct RawDataSavingConfig
{
    /**
     * @brief The FolderRule enum
     *   DEFAULT : Generating the folder by date in format 'yyyymmdd'.
     *   SPECIFIED : Generating the folder defined by user. The path must be legal.
     *   EVERY_START: Generating the folder by time in format 'yyyymmddhhmmss' each time Start is
     * called.
     */
    enum class FolderRule
    {
        DEFAULT = 0,
        SPECIFIED = 1,
        EVERY_START = 2
    };
    RawDataSavingConfig(bool enable_saving = false, FolderRule rule = FolderRule::DEFAULT,
                        const std::string &path = "")
        : saving_enabled(enable_saving), rule(rule), path(path)
    {}

    bool saving_enabled{false};            ///< whether to save raw data
    FolderRule rule{FolderRule::DEFAULT};  ///< the rule of folder generation
    std::string path;                      ///< the folder defined by user
};

/**
 * Base class for LiDAR device and playback device
 */
class DLLEXPORT Device
{
public:
    Device() = default;
    ~Device() = default;

    /**
     * @brief Get the uuid of device
     */
    virtual const uuids::uuid &GetDeviceId() const { return m_device_id; }

    /**
     * @brief Check if the device is started
     */
    virtual bool IsStarted() const { return m_started; }

    /**
     * @brief Initialize the device
     * @return true on success, false otherwise
     */
    virtual bool Init() = 0;

    /**
     * @brief Start the device
     */
    virtual bool Start() = 0;

    /**
     * @brief Stop the device
     */
    virtual bool Stop() = 0;
#ifdef ENABLE_INTERNAL_CALIB
    /**
     * @brief Enable the process of calculating the points in the specified bounding box
     * @note  If passing in a callback, the callback will be called per point cloud frame.
     */
    virtual void EnableBoxedPointsDetection(
        const BoundingBox &box,
        std::function<void(uint32_t, const DetectedPointsBox &)> callback) = 0;

    /**
     * @brief Disable the process of calculating the points in the specified bounding box
     */
    virtual void DisableBoxedPointsDetection() = 0;
#endif
protected:
    uuids::uuid m_device_id{uuids::uuid_random_generator{}()};
    std::atomic_bool m_started{false};
};

}}  // namespace onet::lidar
