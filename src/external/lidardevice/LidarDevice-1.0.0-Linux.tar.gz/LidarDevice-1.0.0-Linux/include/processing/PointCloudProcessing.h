/**************************************************************************
 * @file:  PointCloudProcessor.h
 * @brief:
 *
 * Copyright (c) 2020-present O-Net Communications (ShenZhen) Limited.
 * All rights reserved.
 *
 *************************************************************************/

#pragma once

#include <DeviceParams.h>
#include <DolphinDevice.h>
#include <PointCloud.h>
#include <common/Global.h>

#include <memory>

namespace onet { namespace lidar { namespace processing {

struct NoiseCheckParam
{
    float bx{0.0};  // point before the previous point
    float by{0.0};
    float bz{0.0};
    bool cur_in_line{false};  // current point in a line
};

template <typename POINT_T>
struct ChannelData
{
    PointCloud<POINT_T> pointcloud;
    PointCloud<POINT_T> filtered_pointcloud;
    uint32_t pre_mirror_idx{6};
    int32_t direction{-1};
    bool direction_changed{false};
    NoiseCheckParam noise_check_param;
};

enum class NoisePointDispMode
{
    ONLY_DISPLAY_NOISE_POINT = 1,
    ONLY_DISPLAY_NORMAL_POINT,
    DISPLAY_ALL_POINTS
};

/**
 * @brief Enable or disable noise points removal
 * true: enable, false: disable
 */
void DLLEXPORT SetRemovedNoisePoints(const bool& value);

/**
 * @brief Noise point disply mode
 * 1:noise 2:non-noise 3:all
 */
void DLLEXPORT SetNoisePointDispMode(const enum NoisePointDispMode& mode);

/**
 * @brief Set noise distance threshold in meter, larger number means less noise points
 */
void DLLEXPORT SetNoiseDistThreshold(const float& value);

/**
 * @brief Set noise squared area (0 ~ 1) for filtering out the wrong noise points, larger number
 * means more wrong noise points which are corrected, however, larger number means more correct
 * noise points which are not considered as noise points
 */
void DLLEXPORT SetNoiseAreaSq(const float& value);

/**
 * @brief Set noise range in meter, only filter out noise point inside this range
 */
void DLLEXPORT SetNoiseRange(const float& value);

template <typename POINT_T>
void UpdatePointcloudAftProcessing(ChannelData<POINT_T>& channel_data,
                                   PointCloud<POINT_T>& pointcloud);

bool DLLEXPORT InitDeviceParams(DlphDeviceParameter* dev_params);

template <typename POINT_T>
void ProcessFPGARawDataEigen(const DlphDeviceParameter& dev_param, const DlphFPGAData& data,
                             uint32_t& point_idx, PointCloud<POINT_T>& pointcloud);

template <typename POINT_T>
void ProcessFPGARawData(const DlphDeviceParameter& dev_param, const DlphFPGAData& data,
                        ChannelData<POINT_T>& channel_data);

template <typename POINT_T>
void NoiseRemoval(uint32_t& mirror_idx, POINT_T point, ChannelData<POINT_T>& channel_data);

template <typename POINT_T>
void ProcessFPGARawDataNoiseRemoval(const DlphDeviceParameter& dev_param, const DlphFPGAData& fpga,
                                    ChannelData<POINT_T> (&channel_data)[2],
                                    PointCloud<POINT_T>& pointcloud);

bool GetLeftSource(float data, int32_t& left_source, bool is_max, DlphDeviceParameter* dev_params);

bool GetGalvanometerParameter(const std::vector<uint16_t>& in_data, std::vector<uint16_t>& put_data,
                              DlphDeviceParameter* dev_params);

template <typename POINT_T>
void SetPoint(POINT_T& point, float i, int sec_num, int pulse_wid, int echo_number, int mirror,
              int azm, int elv, int dist);

bool DLLEXPORT CalculateTheoreticalPointsInBox(const DlphDeviceParameter& dev_param,
                                               const float angle_box_up, const float angle_box_down,
                                               const float angle_box_left,
                                               const float angle_box_right,
                                               uint32_t& num_points_in_box);

/**
 * @brief Calculate the theoretical points in the specified bounding box based on the collected raw
 * data
 */
bool DLLEXPORT CalculateTheoreticalPointsInBoxUsingData(
    const DlphDeviceParameter& dev_param, const DlphFPGAData& data, const float angle_box_up,
    const float angle_box_down, const float angle_box_left, const float angle_box_right,
    uint32_t& num_points_in_box);

}}}  // namespace onet::lidar::processing
