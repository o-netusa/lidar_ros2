var searchData=
[
  ['registerpointcloudcallback',['RegisterPointCloudCallback',['../classonet_1_1lidar_1_1LidarDevice.html#acf63cd6ff4172f682cd0619473b1d599',1,'onet::lidar::LidarDevice::RegisterPointCloudCallback()'],['../classonet_1_1lidar_1_1PlaybackDevice.html#a405b6fd12bcc6b5f12e8f1232bf03421',1,'onet::lidar::PlaybackDevice::RegisterPointCloudCallback()']]],
  ['removedevice',['RemoveDevice',['../classonet_1_1lidar_1_1DeviceManager.html#ae390857c29322306fd74817902e5a67d',1,'onet::lidar::DeviceManager']]],
  ['reset',['Reset',['../classonet_1_1lidar_1_1LidarDevice.html#a424e4d539f4bf7293fb319307df1d18a',1,'onet::lidar::LidarDevice']]]
];
